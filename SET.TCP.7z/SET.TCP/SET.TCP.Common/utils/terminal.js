"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const process = require("process");
const readline = require("readline");
var TerminalUtils;
(function (TerminalUtils) {
    TerminalUtils.clearScreen = () => {
        process.stdout.write('\u001B[2J\u001B[0;0f');
    };
    TerminalUtils.createPrompter = (msg) => () => console.log("\n\n** Press ENTER to send a message to the Broker. Type 'exit' to terminate");
    TerminalUtils.createTerminalReader = (useTerminal = true) => readline.createInterface({
        input: process.stdin,
        output: process.stdout,
        terminal: useTerminal
    });
})(TerminalUtils = exports.TerminalUtils || (exports.TerminalUtils = {}));
//# sourceMappingURL=terminal.js.map