import process = require("process");
import readline = require('readline');
import * as events from 'events';

export namespace TerminalUtils {
    export const clearScreen = () => {
        process.stdout.write('\u001B[2J\u001B[0;0f');
    }

    export const createPrompter = (msg: string): Function =>
        () => console.log("\n\n** Press ENTER to send a message to the Broker. Type 'exit' to terminate");

    export const createTerminalReader = (useTerminal: boolean = true): events.EventEmitter =>
        readline.createInterface({
            input: process.stdin,
            output: process.stdout,
            terminal: useTerminal
        });
}