/// <reference types="node" />
import * as events from 'events';
export declare namespace TerminalUtils {
    const clearScreen: () => void;
    const createPrompter: (msg: string) => Function;
    const createTerminalReader: (useTerminal?: boolean) => events.EventEmitter;
}
