export interface ClientOptions {
    role: string;
    hostName: string;
    queueName: string;
}
