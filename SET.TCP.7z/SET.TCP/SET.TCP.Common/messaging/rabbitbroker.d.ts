/// <reference types="node" />
import * as events from 'events';
import { ClientOptions } from '../cfg/clientoptions';
import { MessagingBroker } from './broker';
export declare class RabbitMessagingBroker extends events.EventEmitter implements MessagingBroker {
    private options;
    constructor(options: ClientOptions);
    readonly host: string;
    readonly queue: string;
    listenToQueue: (queue?: string) => events.EventEmitter;
    listenWithCallback: (queue: string, callBack: Function) => void;
    bindFanout: (exchange: string, queue: string, callBack: Function) => void;
    bindDirect: (exchange: string, queue: string, key: string, callBack: Function) => void;
    subscribe: (exchange: string, queue: string, key: string, callBack: Function) => void;
    sendDirect: (exchange: string, queue: string, key: string, message: any, callBack: Function) => void;
    sendToQueue: (queue: string, message: any, callBack: Function) => void;
    publish: (exchange: string, topic: string, message: any, callBack: Function) => void;
}
