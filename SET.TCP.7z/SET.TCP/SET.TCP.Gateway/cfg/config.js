"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.options = {
    queueName: 'SET_TCP_fromAggregator',
    hostName: 'amqp://localhost'
};
//# sourceMappingURL=config.js.map