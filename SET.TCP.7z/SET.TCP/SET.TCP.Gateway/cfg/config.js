"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.options = {
    servers: {
        tmna: {
            role: "Tmna",
            queueName: 'SET_TCP_fromTMNA',
            hostName: 'amqp://localhost'
        },
        logger: {
            role: "Logger",
            queueName: 'SET_TCP_Logger',
            hostName: 'amqp://localhost'
        },
        gateway: {
            role: "Gateway",
            queueName: 'SET_TCP_fromGateway',
            hostName: 'amqp://localhost'
        },
        aggregator: {
            role: "Aggregator",
            queueName: 'SET_TCP_fromAggregator',
            hostName: 'amqp://localhost'
        },
        inference: {
            role: "Inference",
            queueName: 'SET_TCP_fromInference',
            hostName: 'amqp://localhost'
        }
    }
};
//# sourceMappingURL=config.js.map