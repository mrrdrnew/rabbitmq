export const options = {
    queueName: 'SET_TCP_fromAggregator' as string,
    hostName: 'amqp://localhost' as string
}
