export const options = {
    servers: {
        tmna: {
            role: "Tmna",
            queueName: 'SET_TCP_fromTMNA' as string,
            hostName: 'amqp://localhost' as string
        },
        logger: {
            role: "Logger",
            queueName: 'SET_TCP_Logger' as string,
            hostName: 'amqp://localhost' as string
        },
        gateway: {
            role: "Gateway",
            queueName: 'SET_TCP_fromGateway' as string,
            hostName: 'amqp://localhost' as string
        },
        aggregator: {
            role: "Aggregator",
            queueName: 'SET_TCP_fromAggregator' as string,
            hostName: 'amqp://localhost' as string
        },
        inference: {
            role: "Inference",
            queueName: 'SET_TCP_fromInference' as string,
            hostName: 'amqp://localhost' as string
        }
    }
}
