export declare const options: {
    queueName: string;
    hostName: string;
};
