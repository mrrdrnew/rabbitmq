export declare const options: {
    servers: {
        tmna: {
            role: string;
            queueName: string;
            hostName: string;
        };
        logger: {
            role: string;
            queueName: string;
            hostName: string;
        };
        gateway: {
            role: string;
            queueName: string;
            hostName: string;
        };
        aggregator: {
            role: string;
            queueName: string;
            hostName: string;
        };
        inference: {
            role: string;
            queueName: string;
            hostName: string;
        };
    };
};
