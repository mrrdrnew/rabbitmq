"use strict";

var worker = {};

var config = require('./../../cfg/config');
var amqp = require('amqplib/callback_api');

worker.listen = function(cb) {
  listen(config.amqpHost, config.amqpQueue, cb);
}

function listen(host, queue, cb) {
  try {
    amqp.connect(host, function(err, conn) {
      if (err) {
        cb(err);
        return;
      }
      conn.createChannel(function(err, ch) {
        if (err) {
          cb(err);
          return;
        }
        var q = queue;

        ch.assertQueue(q, {durable: true});
        ch.prefetch(1);
        console.log(" [*] Waiting for messages in %s.", q);
        ch.consume(q, function(msg) {
          ch.ack(msg);
          cb(null, msg);
        }, {noAck: false});
      });
    });
  } catch(e) {
    cb(e);
  }
}

module.exports = worker;
