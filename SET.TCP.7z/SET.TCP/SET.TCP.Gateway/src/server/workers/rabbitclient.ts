import * as amqp from "amqplib";
import * as Promise from 'bluebird';
import * as events from 'events';

export interface IClientOptions {
    role: string;
    hostName: string;
    queueName: string;
}

export class MessagingClient extends events.EventEmitter {
    constructor(private options: IClientOptions) {
        super();

        if (!this.options) {
            throw "No configuration options provided...";
        }
    }

    public get host(): string { return this.options.hostName; }

    public get queue(): string { return this.options.queueName; }

    ////////////////////////////////////////////////
    // Notes:
    // Fluent API based on events
    public listenToQueue = (queue?: string): events.EventEmitter => {
        try {
            queue = queue || this.queue;
            amqp.connect(this.host)
                .then(conn => {
                    conn.createChannel()
                        .then(ch => {
                            ch.assertQueue(queue, { durable: true });
                            ch.prefetch(1);
                            console.log(`[*] Waiting for messages in ${queue}`);

                            ch.consume(queue, msg => {
                                // console.log(`\nStart Msg Received at: ${new Date()}`);
                                ch.ack(msg);
                                this.emit("new-message", msg);
                                // console.log(`\nEnd Msg Received at: ${new Date()}\n`);
                            },
                                { noAck: false });
                        },
                        err => {
                            this.emit("error", err);
                        })
                },
                err => {
                    this.emit("error", err);
                },
            );
        }
        catch (err) {
            this.emit("error", err);
        }

        return this;
    }

    ////////////////////////////////////////////////
    // Notes:
    // Old style API based on callbacks
    public listen = (queue: string, callBack: Function): void => {
        try {
            queue = queue || this.queue;
            amqp.connect(this.host)
                .then(conn => {
                    conn.createChannel()
                        .then(ch => {
                            ch.assertQueue(queue, { durable: true });
                            ch.prefetch(1);
                            console.log(`[*] Waiting for messages in ${queue}`);

                            ch.consume(queue, msg => {
                                console.log(`Start Msg Received at: ${new Date()}`);
                                ch.ack(msg);
                                callBack(null, msg);
                                console.log(`End Msg Received at: ${new Date()}`);
                            },
                                { noAck: false });
                        },
                        err => {
                            callBack(err);
                        })
                },
                err => {
                    callBack(err);
                },
            );
        }
        catch (e) {
            callBack(e);
        }
    }

    public bindFanout = (exchange: string, queue: string, callBack: Function): void => {
        try {
            amqp.connect(this.host)
                .then(conn => {
                    conn.createChannel()
                        .then(ch => {
                            exchange = exchange || "fanout-exchange";
                            queue = queue || this.queue;

                            const options = {
                                durable: true
                            };

                            ch.assertExchange(exchange, "fanout", options)
                                .then((_) => {
                                    // ch.bindQueue(queue, exchange, "*");
                                });
                        },
                        err => {
                            callBack(err);
                        })
                },
                err => {
                    callBack(err);
                },
            );
        }
        catch (e) {
            callBack(e);
        }
    }

    public bindDirect = (exchange: string, queue: string, key: string, callBack: Function): void => {
        try {
            amqp.connect(this.host)
                .then(conn => {
                    conn.createChannel()
                        .then(ch => {
                            exchange = exchange || "direct-exchange";
                            queue = queue || this.queue;

                            const options = {
                                durable: true
                            };

                            ch.assertExchange(exchange, "direct", options)
                                .then((_) => {
                                    ch.bindQueue(queue, exchange, key);
                                });
                        },
                        err => {
                            callBack(err);
                        })
                },
                err => {
                    callBack(err);
                },
            );
        }
        catch (e) {
            callBack(e);
        }
    }

    public subscribe = (exchange: string, queue: string, key: string, callBack: Function): void => {
        try {
            amqp.connect(this.host)
                .then(conn => {
                    conn.createChannel()
                        .then(ch => {
                            exchange = exchange || "topic-exchange";
                            queue = queue || this.queue;

                            const options = {
                                durable: true
                            };

                            ch.assertExchange(exchange, "topic", options)
                                .then((_) => {
                                    ch.bindQueue(queue, exchange, key);
                                });
                        },
                        err => {
                            callBack(err);
                        })
                },
                err => {
                    callBack(err);
                },
            );
        }
        catch (e) {
            callBack(e);
        }
    }

    public sendDirect = (exchange: string, queue: string, key: string, message: any, callBack: Function): void => {
        try {
            amqp.connect(this.host)
                .then(conn => {
                    conn.createChannel()
                        .then(ch => {
                            exchange = exchange || "direct-exchange";
                            queue = queue || this.queue;

                            const options = {
                                durable: true
                            };

                            ch.assertExchange(exchange, "direct", options)
                                .then((_) => {
                                    ch.bindQueue(queue, exchange, key);
                                    ch.publish(exchange, key, Buffer.from(message));
                                });
                        },
                        err => {
                            callBack(err);
                        })
                },
                err => {
                    callBack(err);
                },
            );
        }
        catch (e) {
            callBack(e);
        }
    }

    public sendToQueue = (queue: string, message: any, callBack: Function): void => {
        try {
            queue = queue || this.queue;
            amqp.connect(this.host)
                .then(conn => {
                    conn.createChannel()
                        .then(ch => {
                            ch.sendToQueue(queue, Buffer.from(message));
                        },
                        err => {
                            callBack(err);
                        })
                },
                err => {
                    callBack(err);
                },
            );
        }
        catch (e) {
            callBack(e);
        }
    }

    public publish = (exchange: string, queue: string, key: string, message: any, callBack: Function): void => {
        try {
            amqp.connect(this.host)
                .then(conn => {
                    conn.createChannel()
                        .then(ch => {
                            exchange = exchange || "topic-exchange";
                            queue = queue || this.queue;

                            const options = {
                                durable: true
                            };

                            ch.assertExchange(exchange, "topic", options)
                                .then((_) => {
                                    ch.bindQueue(queue, exchange, key);
                                    ch.publish(exchange, key, Buffer.from(message));
                                });
                        },
                        err => {
                            callBack(err);
                        })
                },
                err => {
                    callBack(err);
                },
            );
        }
        catch (e) {
            callBack(e);
        }
    }
}
