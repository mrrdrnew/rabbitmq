import process = require("process");
import {Worker} from "./abstract";

// const moduleId = "External";
// console.log(`[${moduleId}] Worker Process ID: '${process.pid}'`);
const worker = new (class External extends Worker {
    constructor() {
        super("External");
    }
})();
worker.start();
