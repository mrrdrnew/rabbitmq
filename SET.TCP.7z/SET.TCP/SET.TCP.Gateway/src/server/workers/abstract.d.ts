export declare abstract class Worker {
    protected moduleId: string;
    constructor(moduleId: string);
    start(): void;
}
