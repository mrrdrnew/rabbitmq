console.log(`Worker Process ID: '${process.pid}'`);
//# sourceMappingURL=fake_message_processor.js.map