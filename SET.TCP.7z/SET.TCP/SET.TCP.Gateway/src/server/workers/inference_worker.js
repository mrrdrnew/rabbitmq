"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const abstract_1 = require("./abstract");
// const moduleId = "Inference";
// console.log(`[${moduleId}] Worker Process ID: '${process.pid}'`);
const worker = new (class Inference extends abstract_1.Worker {
    constructor() {
        super("Inference");
    }
})();
worker.start();
//# sourceMappingURL=inference_worker.js.map