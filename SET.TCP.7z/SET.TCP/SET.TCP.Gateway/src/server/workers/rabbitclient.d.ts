/// <reference types="node" />
import * as events from 'events';
export interface IClientOptions {
    role: string;
    hostName: string;
    queueName: string;
}
export declare class MessagingClient extends events.EventEmitter {
    private options;
    constructor(options: IClientOptions);
    readonly host: string;
    readonly queue: string;
    listenToQueue: (queue?: string) => events.EventEmitter;
    listen: (queue: string, callBack: Function) => void;
    bindFanout: (exchange: string, queue: string, callBack: Function) => void;
    bindDirect: (exchange: string, queue: string, key: string, callBack: Function) => void;
    subscribe: (exchange: string, queue: string, key: string, callBack: Function) => void;
    sendDirect: (exchange: string, queue: string, key: string, message: any, callBack: Function) => void;
    sendToQueue: (queue: string, message: any, callBack: Function) => void;
    publish: (exchange: string, queue: string, key: string, message: any, callBack: Function) => void;
}
