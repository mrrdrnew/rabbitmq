"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const amqp = require("amqplib");
class MessagingClient {
    constructor(options) {
        this.options = options;
        this.listen = (queue, callBack) => {
            try {
                queue = queue || this.queue;
                amqp.connect(this.host)
                    .then(conn => {
                    conn.createChannel()
                        .then(ch => {
                        ch.assertQueue(queue, { durable: true });
                        ch.prefetch(1);
                        console.log(`[*] Waiting for messages in ${queue}`);
                        ch.consume(queue, msg => {
                            console.log(`Start Msg Received at: ${new Date()}`);
                            ch.ack(msg);
                            callBack(null, msg);
                            console.log(`End Msg Received at: ${new Date()}`);
                        }, { noAck: false });
                    }, err => {
                        callBack(err);
                    });
                }, err => {
                    callBack(err);
                });
            }
            catch (e) {
                callBack(e);
            }
        };
        this.bindFanout = (exchange, queue, callBack) => {
            try {
                amqp.connect(this.host)
                    .then(conn => {
                    conn.createChannel()
                        .then(ch => {
                        exchange = exchange || "fanout-exchange";
                        queue = queue || this.queue;
                        const options = {
                            durable: true
                        };
                        ch.assertExchange(exchange, "fanout", options)
                            .then((_) => {
                            ch.bindQueue(queue, exchange, "*");
                        });
                    }, err => {
                        callBack(err);
                    });
                }, err => {
                    callBack(err);
                });
            }
            catch (e) {
                callBack(e);
            }
        };
        this.bindDirect = (exchange, queue, key, callBack) => {
            try {
                amqp.connect(this.host)
                    .then(conn => {
                    conn.createChannel()
                        .then(ch => {
                        exchange = exchange || "direct-exchange";
                        queue = queue || this.queue;
                        const options = {
                            durable: true
                        };
                        ch.assertExchange(exchange, "direct", options)
                            .then((_) => {
                            ch.bindQueue(queue, exchange, key);
                        });
                    }, err => {
                        callBack(err);
                    });
                }, err => {
                    callBack(err);
                });
            }
            catch (e) {
                callBack(e);
            }
        };
        this.subscribe = (exchange, queue, key, callBack) => {
            try {
                amqp.connect(this.host)
                    .then(conn => {
                    conn.createChannel()
                        .then(ch => {
                        exchange = exchange || "topic-exchange";
                        queue = queue || this.queue;
                        const options = {
                            durable: true
                        };
                        ch.assertExchange(exchange, "topic", options)
                            .then((_) => {
                            ch.bindQueue(queue, exchange, key);
                        });
                    }, err => {
                        callBack(err);
                    });
                }, err => {
                    callBack(err);
                });
            }
            catch (e) {
                callBack(e);
            }
        };
        this.sendDirect = (exchange, queue, key, message, callBack) => {
            try {
                amqp.connect(this.host)
                    .then(conn => {
                    conn.createChannel()
                        .then(ch => {
                        exchange = exchange || "direct-exchange";
                        queue = queue || this.queue;
                        const options = {
                            durable: true
                        };
                        ch.assertExchange(exchange, "direct", options)
                            .then((_) => {
                            ch.bindQueue(queue, exchange, key);
                            ch.publish(exchange, key, Buffer.from(message));
                        });
                    }, err => {
                        callBack(err);
                    });
                }, err => {
                    callBack(err);
                });
            }
            catch (e) {
                callBack(e);
            }
        };
        this.sendToQueue = (queue, message, callBack) => {
            try {
                queue = queue || this.queue;
                amqp.connect(this.host)
                    .then(conn => {
                    conn.createChannel()
                        .then(ch => {
                        ch.sendToQueue(queue, Buffer.from(message));
                    }, err => {
                        callBack(err);
                    });
                }, err => {
                    callBack(err);
                });
            }
            catch (e) {
                callBack(e);
            }
        };
        this.publish = (exchange, queue, key, message, callBack) => {
            try {
                amqp.connect(this.host)
                    .then(conn => {
                    conn.createChannel()
                        .then(ch => {
                        exchange = exchange || "topic-exchange";
                        queue = queue || this.queue;
                        const options = {
                            durable: true
                        };
                        ch.assertExchange(exchange, "topic", options)
                            .then((_) => {
                            ch.bindQueue(queue, exchange, key);
                            ch.publish(exchange, key, Buffer.from(message));
                        });
                    }, err => {
                        callBack(err);
                    });
                }, err => {
                    callBack(err);
                });
            }
            catch (e) {
                callBack(e);
            }
        };
        if (!this.options) {
            throw "No configuration options provided...";
        }
        // this.listen(options.hostName, options.queueName, callBack)
    }
    get host() { return this.options.hostName; }
    get queue() { return this.options.queueName; }
}
exports.MessagingClient = MessagingClient;
//# sourceMappingURL=channel.js.map