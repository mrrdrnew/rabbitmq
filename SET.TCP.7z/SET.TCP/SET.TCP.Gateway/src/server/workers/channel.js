"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const amqp = require("amqplib");
class Channel {
    constructor(options, callBack) {
        this.setup = (host, queue, callBack) => {
            try {
                amqp.connect(host)
                    .then(conn => {
                    conn.createChannel()
                        .then(ch => {
                        ch.assertQueue(queue, { durable: true });
                        ch.prefetch(1);
                        console.log(`[*] Waiting for messages in ${queue}`);
                        ch.consume(queue, msg => {
                            ch.ack(msg);
                            callBack(null, msg);
                        }, { noAck: false });
                    }, err => {
                        callBack(err);
                    });
                }, err => {
                    callBack(err);
                });
            }
            catch (e) {
                callBack(e);
            }
        };
        if (!options) {
            throw "No configuration options provided...";
        }
        this.setup(options.hostName, options.queueName, callBack);
    }
}
exports.Channel = Channel;
//# sourceMappingURL=channel.js.map