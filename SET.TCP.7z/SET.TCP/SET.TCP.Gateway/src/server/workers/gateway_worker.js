"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const abstract_1 = require("./abstract");
// const moduleId = "Gateway";
// console.log(`[${moduleId}] Worker Process ID: '${process.pid}'`);
const worker = new (class Gateway extends abstract_1.Worker {
    constructor() {
        super("Gateway");
    }
})();
worker.start();
//# sourceMappingURL=gateway_worker.js.map