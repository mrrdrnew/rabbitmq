"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const abstract_1 = require("./abstract");
// const moduleId = "External";
// console.log(`[${moduleId}] Worker Process ID: '${process.pid}'`);
const worker = new (class External extends abstract_1.Worker {
    constructor() {
        super("External");
    }
})();
worker.start();
//# sourceMappingURL=external_worker.js.map