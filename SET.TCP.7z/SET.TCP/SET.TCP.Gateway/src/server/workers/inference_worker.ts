import process = require("process");
import {Worker} from "./abstract";

// const moduleId = "Inference";
// console.log(`[${moduleId}] Worker Process ID: '${process.pid}'`);
const worker = new (class Inference extends Worker {
    constructor() {
        super("Inference");
    }
})();
worker.start();
