"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const process = require("process");
class Worker {
    constructor(moduleId) {
        this.moduleId = moduleId;
    }
    start() {
        console.log(`[${this.moduleId}] Worker Process ID: '${process.pid}'`);
        // console.dir(this);
        // console.dir(process);
        // process.send({ moduleId: this.moduleId, processId: process.pid});
    }
}
exports.Worker = Worker;
//# sourceMappingURL=abstract.js.map