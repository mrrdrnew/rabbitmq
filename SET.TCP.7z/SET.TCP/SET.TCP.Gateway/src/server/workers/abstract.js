"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Worker {
    constructor(moduleId) {
        this.moduleId = moduleId;
    }
    start() {
        console.log(`[${this.moduleId}] Worker Process ID: '${process.pid}'`);
    }
}
exports.Worker = Worker;
//# sourceMappingURL=abstract.js.map