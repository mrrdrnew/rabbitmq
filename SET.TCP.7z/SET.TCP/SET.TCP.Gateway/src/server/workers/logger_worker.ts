import process = require("process");
import {Worker} from "./abstract";

// const moduleId = "Logger";
// console.log(`[${moduleId}] Worker Process ID: '${process.pid}'`);
const worker = new (class Logger extends Worker {
    constructor() {
        super("Logger");
    }
})();
worker.start();
