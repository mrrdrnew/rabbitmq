"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const abstract_1 = require("./abstract");
// const moduleId = "Logger";
// console.log(`[${moduleId}] Worker Process ID: '${process.pid}'`);
const worker = new (class Logger extends abstract_1.Worker {
    constructor() {
        super("Logger");
    }
})();
worker.start();
//# sourceMappingURL=logger_worker.js.map