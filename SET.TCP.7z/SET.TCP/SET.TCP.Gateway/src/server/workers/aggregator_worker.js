"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const abstract_1 = require("./abstract");
// const moduleId = "Aggregator";
// console.log(`[${moduleId}] Worker Process ID: '${process.pid}'`);
const worker = new (class Aggregator extends abstract_1.Worker {
    constructor() {
        super("Aggregator");
    }
})();
worker.start();
//# sourceMappingURL=aggregator_worker.js.map