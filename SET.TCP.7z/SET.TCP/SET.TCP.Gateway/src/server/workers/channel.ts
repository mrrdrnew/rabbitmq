import * as amqp from "amqplib";

export interface IChannelOptions {
    hostName: string;
    queueName: string;
}

export class Channel {
    constructor(options: IChannelOptions, callBack: (err: any, msg: any) => void) {
        if (!options) {
            throw "No configuration options provided...";
        }

        this.setup(options.hostName, options.queueName, callBack)
    }

    private setup = (host: string, queue: string, callBack: Function) => {
        try {
            amqp.connect(host)
                .then(conn => {
                    conn.createChannel()
                        .then(ch => {
                            ch.assertQueue(queue, { durable: true });
                            ch.prefetch(1);
                            console.log(`[*] Waiting for messages in ${queue}`);

                            ch.consume(queue, msg => {
                                ch.ack(msg);
                                callBack(null, msg);
                            },
                                { noAck: false });
                        },
                        err => {
                            callBack(err);
                        })
                },
                err => {
                    callBack(err);
                },
            );
        }
        catch (e) {
            callBack(e);
        }
    }
}
