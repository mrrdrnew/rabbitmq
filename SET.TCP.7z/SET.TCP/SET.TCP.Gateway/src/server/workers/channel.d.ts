export interface IChannelOptions {
    hostName: string;
    queueName: string;
}
export declare class Channel {
    constructor(options: IChannelOptions, callBack: (err: any, msg: any) => void);
    private setup;
}
