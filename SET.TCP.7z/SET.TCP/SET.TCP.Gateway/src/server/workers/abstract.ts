import process = require("process");

export abstract class Worker {
    constructor(protected moduleId: string) {}

    public start() {
        console.log(`[${this.moduleId}] Worker Process ID: '${process.pid}'`);
        // console.dir(this);
        // console.dir(process);
        // process.send({ moduleId: this.moduleId, processId: process.pid});
    }
}