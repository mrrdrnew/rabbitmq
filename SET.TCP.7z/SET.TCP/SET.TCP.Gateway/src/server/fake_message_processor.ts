console.log(`Worker Process ID: '${process.pid}'`);
process.on("message", x => {
    console.log(`[${process.pid}] Message Received -> ${x}`);
});
