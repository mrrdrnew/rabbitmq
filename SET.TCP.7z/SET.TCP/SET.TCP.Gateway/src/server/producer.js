"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const rabbitclient_1 = require("./workers/rabbitclient");
const config = require("../../cfg/config");
const roleName = "tmna";
const channelInfo = config.options.servers[roleName];
const worker = new rabbitclient_1.MessagingClient(channelInfo);
const setup = () => {
    ///////////////////////////////////////////////////////////////////////////////
    // TODO:
    // Check existing queues && exchanges
    // worker.bindDirect("SET_TCP_fromGateway", "SET_TCP_fromGateway", "*", _ => console.log(_));
    // worker.bindDirect("SET_TCP_fromAggregator", "SET_TCP_fromAggregator", "*", _ => console.log(_));
    // worker.bindDirect("SET_TCP_fromInference", "SET_TCP_fromInference", "*", _ => console.log(_));
    const sourceExchange = "SET_TCP_fromTMNA";
    // worker.bindDirect(sourceExchange, sourceExchange, "unrouted", _ => console.dir(_));
    // Notes: Incoming messages will be logged first
    worker.subscribe(sourceExchange, "SET_TCP_Logger", "#", _ => console.log(_));
    // Notes: Based on the topic, messages will go to their respective route / queue
    worker.subscribe(sourceExchange, "SET_TCP_fromGateway", "set.tcp.gateway", _ => console.log(_));
    worker.subscribe(sourceExchange, "SET_TCP_fromAggregator", "set.tcp.aggregator", _ => console.log(_));
    worker.subscribe(sourceExchange, "SET_TCP_fromInference", "set.tcp.inference", _ => console.log(_));
};
setup();
console.log("\n\n\nSetup completed ...");
const sendFilesDaemon = () => {
    // import fs = require('fs');
    // console.log(`Generating messages every ${timeBetweenMsgs} sec.`)
    ///////////////////////////////////////////////////////////////////////////////
    // TODO:
    //  Implement as tests
    //  i.e.
    //  Worker sends msg to TMNA should fork / route msg to:
    //      - logger 
    //      - corresponding topic exchange if any, otherwise msg stays in the queue
    // function buildBoundedRandomizer(min: number, max: number) {
    //     const segment = Math.abs(max - min);
    //     return () => min + Math.random() * segment;
    // }
    // const timeBetweenMsgs = buildBoundedRandomizer(5, 10)();
    // setInterval(() => {
    // const rnd = Math.random();
    // const fileName = `../../data/${(rnd > 0.5) ? "rtm" : "pcps"}.xml`;
    // fs.readFile(fileName, 'utf8', (err, data) => {
    //     if (err) {
    //         console.error(err);
    //         return;
    //     }
    //     console.log(`Sending copy of file: '${fileName}'`);
    //     // worker.sendToQueue("", JSON.stringify(data), x => console.log(x));
    //     // worker.sendDirect("", "", "all", JSON.stringify(data), x => console.log(x));
    // });
    // }, 1000 * timeBetweenMsgs);
};
const process = require("process");
setTimeout(() => process.exit(), 1000);
//# sourceMappingURL=producer.js.map