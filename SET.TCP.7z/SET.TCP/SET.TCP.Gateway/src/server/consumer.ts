import cluster = require("cluster");
import process = require("process");
import { IClientOptions, MessagingClient } from "./workers/rabbitclient";
import * as config from "../../cfg/config";

if (cluster.isMaster) {
    console.log(`Master Process ID: '${process.pid}'`);

    const roleName = "gateway"; //process.argv[2];
    const channelInfo: IClientOptions = config.options.servers[roleName];

    var master = new MessagingClient(channelInfo);
    // master.listen("", (err, msg) => {
    //     console.log("\n\n")

    //     if (err) {
    //         console.log(`[${channelInfo.role}] Received Error: '${JSON.stringify(err)}'`);
    //         return;
    //     }

    //     console.log(`[${channelInfo.role}] Received Msg: '${msg.content.toString()}'`);
    // });

    let settings: cluster.ClusterSetupMasterSettings = {
        exec: 'node_modules/ts-node/dist/bin.js',
        args: ['./src/server/fake_message_processor'],
        silent: false
    };
    cluster.setupMaster(settings);

            let worker = cluster.fork();

            worker.on('message', function (msg) {
                console.log(msg);
            });
            try {
                debugger;
                worker.send({msgFromMaster: 'This is from master ' + process.pid + ' to worker ' + worker.id + '.'});
            } catch(e) {
                console.log(`Error: ${e}`);
            }
    
    // master.listenToQueue()
    //     .on("new-message", msg => {
    //         let worker = cluster.fork();

    //         debugger;
    //         // worker.send({ hello: "world" });
    //         // console.log(`[${channelInfo.role}] Received Msg: '${msg.content.toString()}'`);
    //         worker.on('message', function (msg) {
    //             console.log(msg);
    //         });
    //         worker.send({msgFromMaster: 'This is from master ' + process.pid + ' to worker ' + worker.id + '.'});

    //         cluster.on('death', function (worker) {
    //             console.log(`Worker ${worker.pid} died.`);
    //         });
    //     })
    //     .on("error", err => {
    //         console.log(`[${channelInfo.role}] Received Error: '${JSON.stringify(err)}'`);
    //         return;
    //     });
}
// else {
//     console.log(`Worker Process ID: '${process.pid}'`);
// }
