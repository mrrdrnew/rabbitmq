"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// import fs = require('fs');
const process = require("process");
const readline = require("readline");
const serviceId = `SMD-${process.pid}`;
const startAgent = () => {
    console.log("******************************************");
    console.log(`** Send Messages Daemon: ${serviceId}`);
    console.log("******************************************");
    const prompter = () => {
        console.log("\n\n** Press ENTER to send a message to the Broker. Type 'exit' to terminate");
    };
    const reader = readline.createInterface({
        input: process.stdin,
        output: process.stdout,
        terminal: true
    });
    prompter();
    reader.on('line', function (line) {
        if (line.toLowerCase().includes("exit")) {
            console.log("\n\n** User requested termination");
            process.exit();
        }
        // TODO: Sending message
        console.log("\nSending message");
        prompter();
    });
    // setInterval(() => {
    // const rnd = Math.random();
    // const fileName = `../../data/${(rnd > 0.5) ? "rtm" : "pcps"}.xml`;
    // fs.readFile(fileName, 'utf8', (err, data) => {
    //     if (err) {
    //         console.error(err);
    //         return;
    //     }
    //     console.log(`Sending copy of file: '${fileName}'`);
    //     // worker.sendToQueue("", JSON.stringify(data), x => console.log(x));
    //     // worker.sendDirect("", "", "all", JSON.stringify(data), x => console.log(x));
    // });
    // }, 1000 * timeBetweenMsgs);
};
startAgent();
//# sourceMappingURL=sendmessages.js.map