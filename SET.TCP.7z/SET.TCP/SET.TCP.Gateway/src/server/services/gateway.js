"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const process = require("process");
const config = require("../../../cfg/config");
const rabbitbroker_1 = require("../../../../set.tcp.common/messaging/rabbitbroker");
const serviceId = `GW-${process.pid}`;
console.log("******************************************");
console.log(`** Gateway Service: ${serviceId}`);
console.log("******************************************");
const roleName = "gateway"; //process.argv[2];
const channelInfo = config.options.servers[roleName];
const service = new rabbitbroker_1.RabbitMessagingBroker(channelInfo);
(() => {
    var Db = require('mongodb').Db, MongoClient = require('mongodb').MongoClient, Server = require('mongodb').Server, ReplSetServers = require('mongodb').ReplSetServers, ObjectID = require('mongodb').ObjectID, Binary = require('mongodb').Binary, GridStore = require('mongodb').GridStore, Grid = require('mongodb').Grid, Code = require('mongodb').Code, 
    // BSON = require('mongodb').pure().BSON,
    assert = require('assert');
    debugger;
    var db = new Db('test-messages', new Server('localhost', 27017));
    // Establish connection to db
    db.open(function (err, db) {
        // Create a file and open it
        var gridStore = new GridStore(db, new ObjectID(), "test_gs_getc_file", "w");
        gridStore.open(function (err, gridStore) {
            // Write some content to the file
            gridStore.write(new Buffer("hello, world!", "utf8"), function (err, gridStore) {
                // Flush the file to GridFS
                gridStore.close(function (err, fileData) {
                    assert.equal(null, err);
                });
            });
        });
    });
    // TODO: Abstract and move to different file(s)
    // const mongo = require('mongodb');
    // const Grid = require('gridfs-stream');
    // // TODO: config setting
    // const dbName = "admin";
    // const server = { ipAddress: "localhost", port: 27017 };
    // const db = new mongo.Db(dbName, new mongo.Server(server.ipAddress, server.port));
    // db.open(err => {
    //     if (err) {
    //         console.log(err);
    //         process.exit(err.code);
    //     }
    //     const gfs = Grid(db, mongo);
    //     const options = {
    //         // _id: '50e03d29edfdc00d34000001', // a MongoDb ObjectId 
    //         // filename: `rtm-msg.xml`,
    //         // mode: 'w', // default value: w 
    //         // //any other options from the GridStore may be passed too, e.g.: 
    //         // chunkSize: 1024,
    //         // content_type: 'text/xml', // For content_type to work properly, set "mode"-option to "w" too! 
    //         // root: 'rtm-messages',
    //         // // metadata: {
    //         // //     ...
    //         // // }
    //     };
    // const writeStream = gfs.createWriteStream(options);
    // const Duplex = require('stream').Duplex;
    // const stream = new Duplex();
    // stream.push(Buffer.from("Test message !!!"));
    // stream.push(null);
    // stream.pipe(writeStream);
})();
service.listenToQueue()
    .on("new-message", msg => {
    console.log(`\n[${serviceId}] Message Received: ${msg.content.toString()}`);
})
    .on("error", err => {
    console.log(`\n[${channelInfo.role}] Error Received: '${JSON.stringify(err)}'`);
    return;
});
//# sourceMappingURL=gateway.js.map