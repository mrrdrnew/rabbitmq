"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const process = require("process");
const fs = require("fs");
const terminal_1 = require("../../../../set.tcp.common/utils/terminal");
const config = require("../../../cfg/config");
const rabbitbroker_1 = require("../../../../set.tcp.common/messaging/rabbitbroker");
const roleName = "tmna";
const channelInfo = config.options.servers[roleName];
const broker = new rabbitbroker_1.RabbitMessagingBroker(channelInfo);
const startAgent = () => {
    terminal_1.TerminalUtils.clearScreen();
    const serviceId = `SMD-${process.pid}`;
    console.log("******************************************");
    console.log(`** Send Messages Daemon: ${serviceId}`);
    console.log("******************************************");
    const prompter = terminal_1.TerminalUtils.createPrompter("\n\n** Press ENTER to send a message to the Broker. Type 'exit' to terminate");
    prompter();
    const reader = terminal_1.TerminalUtils.createTerminalReader();
    reader.on('line', function (line) {
        if (line.toLowerCase().includes("exit")) {
            console.log("\n\n** User requested termination");
            process.exit();
        }
        sendMessage();
    });
    ///////////////////////////////////
    // Notes: Pass in args:
    //  - exchange topic to publish
    //  - message type to use RTM | PCPS
    const getArg = (index) => index < process.argv.length ? process.argv[index] : null;
    const exchange = channelInfo.queueName;
    const topic = getArg(2) || "set.tcp.gateway";
    const fileType = getArg(3) || "rtm";
    const fileName = `../../../data/${fileType}.xml`;
    const sendMessage = () => {
        console.log("\nSending message");
        /////////
        // Notes: re-reading the file each time on purpose to increase processing time between calls
        fs.readFile(fileName, 'utf8', (err, data) => {
            if (err) {
                console.error(err);
                return;
            }
            console.log(`[${exchange}:${topic}}] -> Sending message with copy of file: '${fileName}'`);
            broker.publish(exchange, topic, JSON.stringify(data), response => {
                console.dir(response);
                prompter();
            });
        });
    };
};
startAgent();
//# sourceMappingURL=sender.js.map