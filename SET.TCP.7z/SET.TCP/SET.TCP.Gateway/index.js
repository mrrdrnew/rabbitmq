const worker = require('./src/server/worker');

worker.listen(function(err, msg) {
  if (err) {
    console.log(" [x] Received Error", JSON.stringify(err));
    return;
  }
  console.log(" [x] Received %s", msg.content.toString());
});
