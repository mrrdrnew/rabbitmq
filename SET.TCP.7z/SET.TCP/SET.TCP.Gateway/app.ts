// /// <reference path="node_modules/@types/node/index.d.ts" />

// // import * as config from "./cfg/config";
// // import { IChannelOptions, Channel } from "./src/server/worker2";

// // var worker = new Channel(config.options as IChannelOptions, (err, msg) => {
// //     if (err) {
// //         console.log(`[x] Received Error: '${JSON.stringify(err)}'`);
// //         return;
// //     }

// //     console.log(`[x] Received Msg: '${msg.content.toString()}'`);
// // });

// // import os = require("os");
// import process = require("process");

// import cluster = require("cluster");

// if (cluster.isMaster) {
//     console.log(`Master Process ID: '${process.pid}'`);

//     const workers = [
//         "external_worker",
//         "gateway_worker",
//         "aggregator_worker",
//         "inference_worker",
//         "logger_worker"
//     ];
//     const workersPath = "./src/server/workers/";

//     let settings: cluster.ClusterSetupMasterSettings = {
//         exec: 'node_modules/ts-node/dist/bin.js',
//         // args: ['./src/server/gateway_worker'],
//         silent: false
//     };

//     // os.cpus().forEach(x => {
//     //     cluster.setupMaster(settings);
//     //     cluster.fork();
//     // });

//     workers.forEach(x => {
//         settings.args = [`${workersPath}${x}`];
//         cluster.setupMaster(settings);
        
//         const worker = cluster.fork();

//         // TODO: Connect to events
//         worker.on("message", (data) => {
//             console.log(`[${x}] -> Worker Receiving Data: [${data}]`);
//         });
//     });

//     process.on("message", (data) => {
//         console.log(`[Master] -> Receiving Data: [${data}]`);
//     });

// } else {
//     console.log(`Worker Process ID: '${process.pid}', args: [${process.argv}`);
// }
